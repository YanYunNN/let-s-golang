create view v_schedule as
select `fits2.0`.`schedule`.`ID`                                 AS `ID`,
       `fits2.0`.`schedule`.`DATE`                               AS `DATE`,
       from_unixtime((`fits2.0`.`schedule`.`BEGIN_TIME` / 1000)) AS `BEGIN_TIME`,
       from_unixtime((`fits2.0`.`schedule`.`END_TIME` / 1000))   AS `END_TIME`,
       `fits2.0`.`schedule`.`MODEL_ID`                           AS `MODEL_ID`,
       `fits2.0`.`schedule`.`QUANTITY`                           AS `QUANTITY`,
       `fits2.0`.`schedule`.`SERIAL_NUMBER`                      AS `SERIAL_NUMBER`
from `fits2.0`.`schedule`;

