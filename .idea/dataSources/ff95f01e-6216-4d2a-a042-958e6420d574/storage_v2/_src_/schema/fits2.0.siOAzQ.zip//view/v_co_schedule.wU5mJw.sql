create view v_co_schedule as
select `fits2.0`.`co_schedule`.`ID`                                 AS `ID`,
       `fits2.0`.`co_schedule`.`MACHINE_ID`                         AS `MACHINE_ID`,
       `fits2.0`.`co_schedule`.`SRC_MODEL`                          AS `SRC_MODEL`,
       `fits2.0`.`co_schedule`.`DEST_MODEL`                         AS `DEST_MODEL`,
       from_unixtime((`fits2.0`.`co_schedule`.`BEGIN_TIME` / 1000)) AS `BEGIN_TIME`,
       from_unixtime((`fits2.0`.`co_schedule`.`END_TIME` / 1000))   AS `END_TIME`,
       from_unixtime(`fits2.0`.`co_schedule`.`CREATE_TIME`)         AS `CREATE_TIME`,
       `fits2.0`.`co_schedule`.`STATE`                              AS `STATE`
from `fits2.0`.`co_schedule`;

