create view `v_job&rack` as
select `fits2.0`.`job`.`ID`            AS `ID`,
       `fits2.0`.`job`.`MODEL_ID`      AS `MODEL_ID`,
       `fits2.0`.`job`.`CAPACITY`      AS `CAPACITY`,
       `fits2.0`.`job`.`MACHINE_ID`    AS `MACHINE_ID`,
       `fits2.0`.`job`.`RACK_ID`       AS `RACK_ID`,
       `fits2.0`.`job`.`MODEL_NAME`    AS `MODEL_NAME`,
       `fits2.0`.`job`.`PROCESS_NAME`  AS `PROCESS_NAME`,
       `fits2.0`.`job`.`MACHINE_NAME`  AS `MACHINE_NAME`,
       `fits2.0`.`job`.`RFID`          AS `RFID`,
       `fits2.0`.`job`.`STATUS`        AS `STATUS`,
       `fits2.0`.`job`.`MODIFIED`      AS `MODIFIED`,
       `fits2.0`.`job`.`AMOUNT`        AS `AMOUNT`,
       `fits2.0`.`job`.`INTERRUPT`     AS `INTERRUPT`,
       `fits2.0`.`job`.`INTERRUPT_EXT` AS `INTERRUPT_EXT`
from `fits2.0`.`job`
where ((`fits2.0`.`job`.`MACHINE_ID` = (select `fits2.0`.`machine`.`ID` AS `machineCode`
                                        from `fits2.0`.`machine`
                                        where (`fits2.0`.`machine`.`NUMBER` = '02-003-039'))) and
       (`fits2.0`.`job`.`RACK_ID` =
        (select `fits2.0`.`rack`.`ID` from `fits2.0`.`rack` where (`fits2.0`.`rack`.`LOCATION_ID` = '40.10.1.4'))));

