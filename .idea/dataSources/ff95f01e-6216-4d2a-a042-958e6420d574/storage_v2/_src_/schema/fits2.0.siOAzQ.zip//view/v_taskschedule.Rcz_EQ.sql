create view v_taskschedule as
select `fits2.0`.`task_schedule`.`ID`                                 AS `ID`,
       from_unixtime((`fits2.0`.`task_schedule`.`DATE` / 1000))       AS `DATE_STR`,
       from_unixtime((`fits2.0`.`task_schedule`.`BEGIN_TIME` / 1000)) AS `BEGIN_DATE`,
       from_unixtime((`fits2.0`.`task_schedule`.`END_TIME` / 1000))   AS `END_DATE`,
       `fits2.0`.`task_schedule`.`QUANTITY`                           AS `QUANTITY`,
       `fits2.0`.`task_schedule`.`MODEL_ID`                           AS `MODEL_ID`,
       `fits2.0`.`task_schedule`.`TYPE`                               AS `TYPE`,
       `fits2.0`.`task_schedule`.`MODEL_NAME`                         AS `MODEL_NAME`
from `fits2.0`.`task_schedule`;

