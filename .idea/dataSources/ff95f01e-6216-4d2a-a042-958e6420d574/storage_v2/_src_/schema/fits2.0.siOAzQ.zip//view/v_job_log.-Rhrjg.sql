create view v_job_log as
select `fits2.0`.`job_log`.`ID`                                  AS `ID`,
       `fits2.0`.`job_log`.`MODEL_ID`                            AS `MODEL_ID`,
       `fits2.0`.`job_log`.`LOCATION_ID`                         AS `LOCATION_ID`,
       from_unixtime((`fits2.0`.`job_log`.`DATE` / 1000))        AS `DATE`,
       from_unixtime((`fits2.0`.`job_log`.`CREATE_TIME` / 1000)) AS `CREATE_TIME`,
       `fits2.0`.`job_log`.`STATUS`                              AS `STATUS`,
       `fits2.0`.`job_log`.`RFID`                                AS `RFID`
from `fits2.0`.`job_log`;

