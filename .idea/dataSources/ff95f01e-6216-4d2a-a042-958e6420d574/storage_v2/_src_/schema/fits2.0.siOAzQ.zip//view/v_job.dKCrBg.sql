create view v_job as
select `fits2.0`.`job`.`ID`            AS `ID`,
       `fits2.0`.`job`.`STATUS`        AS `STATUS`,
       `fits2.0`.`job`.`RACK_ID`       AS `RACK_ID`,
       `fits2.0`.`job`.`PROCESS_NAME`  AS `PROCESS_NAME`,
       `fits2.0`.`job`.`MACHINE_NAME`  AS `MACHINE_NAME`,
       `fits2.0`.`job`.`MODEL_NAME`    AS `MODEL_NAME`,
       `fits2.0`.`job`.`RFID`          AS `RFID`,
       `fits2.0`.`job`.`MODIFIED`      AS `MODIFIED`,
       `fits2.0`.`job`.`AMOUNT`        AS `AMOUNT`,
       `fits2.0`.`job`.`INTERRUPT`     AS `INTERRUPT`,
       `fits2.0`.`job`.`INTERRUPT_EXT` AS `INTERRUPT_EXT`
from `fits2.0`.`job`;

