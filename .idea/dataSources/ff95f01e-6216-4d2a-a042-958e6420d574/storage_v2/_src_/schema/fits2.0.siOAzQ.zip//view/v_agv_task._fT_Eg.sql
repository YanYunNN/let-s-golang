create view v_agv_task as
select `fits2.0`.`agv_task`.`ID`            AS `ID`,
       `fits2.0`.`agv_task`.`STATUS`        AS `STATUS`,
       `fits2.0`.`agv_task`.`CREATE_TIME`   AS `CREATE_TIME`,
       `fits2.0`.`agv_task`.`SRC_DEVICE`    AS `SRC_DEVICE`,
       `fits2.0`.`agv_task`.`DEST_DEVICE`   AS `DEST_DEVICE`,
       `fits2.0`.`agv_task`.`RFID`          AS `RFID`,
       `fits2.0`.`agv_task`.`SRC_LOCATION`  AS `SRC_LOCATION`,
       `fits2.0`.`agv_task`.`DEST_LOCATION` AS `DEST_LOCATION`,
       `fits2.0`.`agv_task`.`TASK_ID`       AS `TASK_ID`,
       `fits2.0`.`agv_task`.`SRC_MACHINE`   AS `SRC_MACHINE`,
       `fits2.0`.`agv_task`.`DEST_MACHINE`  AS `DEST_MACHINE`
from `fits2.0`.`agv_task`;

