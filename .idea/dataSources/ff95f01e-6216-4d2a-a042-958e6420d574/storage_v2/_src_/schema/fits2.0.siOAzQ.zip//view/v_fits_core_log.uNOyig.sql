create view v_fits_core_log as
select `fits2.0`.`fits_core_log`.`ID`                                 AS `ID`,
       from_unixtime((`fits2.0`.`fits_core_log`.`BEGIN_TIME` / 1000)) AS `BEGIN_DATE`,
       from_unixtime((`fits2.0`.`fits_core_log`.`END_TIME` / 1000))   AS `END_DATE`,
       `fits2.0`.`fits_core_log`.`BEGIN_TIME`                         AS `BEGIN_TIME`,
       `fits2.0`.`fits_core_log`.`END_TIME`                           AS `END_TIME`,
       `fits2.0`.`fits_core_log`.`STATUS`                             AS `STATUS`,
       `fits2.0`.`fits_core_log`.`EXIT_CODE`                          AS `EXIT_CODE`
from `fits2.0`.`fits_core_log`;

